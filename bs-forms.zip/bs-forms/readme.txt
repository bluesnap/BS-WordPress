﻿=== BlueSnap All in One Platform ===
Contributors: bluesnap
Tags: modal forms , payment
Requires at least: 4.6
Tested up to: 4.9
Stable tag: 4.3
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
 
You can accept credit and debit cards with BlueSnap from your WordPress site without the need for an additional shopping cart plugin.
 
== Description ==
 
In a few simple steps you can start accepting credit and debit cards with BlueSnap’s Hosted Payment Form from your WordPress site.
 
What is the BlueSnap Hosted Payment Form?
 
BlueSnap’s Hosted Payment Form is an embeddable payment form for desktop, tablet, and mobile devices. It works by allowing your customers to securely checkout without leaving your site, while also reducing your PCI compliance.
 
If you want to easily accept credit and debit card payments around the world then the BlueSnap all-in-one Gateway with Hosted Fields is what you need.
 
Main featured :
- Unlimited payment forms
- Responsive design for desktop and mobile 
- Support for multi-languages and 100 currencies
- Ability to customize payment success page
- Live/Test mode toggle
 
== Installation ==
 
1. Upload the plugin files to the `/wp-content/plugins/bs-forms` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->BlueSnap settings screen to configure the plugin
4. Refer to the BlueSnap site for additional instructions:  https://support.bluesnap.com/v5.0/docs/wordpress-setup